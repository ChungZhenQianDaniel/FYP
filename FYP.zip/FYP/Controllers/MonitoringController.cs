﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Authorization;
using MySql.Data.MySqlClient;
using static System.Net.Mime.MediaTypeNames;
using System.Diagnostics;
using Newtonsoft.Json;

namespace FYP.Controllers;

public class MonitoringController : Controller
{
    public string SQLName = "";

    [AllowAnonymous]
    public IActionResult About()
    {
        return View();
    }
    [Authorize(Roles = "admin, farmer")]
    public IActionResult Dashboard()
    {
        /*string insert =
               @"LOAD DATA INFILE '~/CSV/feeds.csv'
                    INTO TABLE employee_details
                    FIELDS TERMINATED BY ','
                    IGNORE 1 ROWS;";
        int res = DBUtl.ExecSQL(insert);*/
        return View();
    }

        //test
    [Authorize(Roles = "admin, farmer")]
    public IActionResult test2()
    {
        
        // Create MySQL connection and define Query
        MySqlConnection conn = new MySqlConnection("server=localhost;uid=root;pwd=;database=esp32");
        MySqlCommand query = new MySqlCommand("SELECT * FROM dht22", conn);

        // Open connection and execute query
        conn.Open();
        MySqlDataReader execute = query.ExecuteReader();

        // Read data into list
        List<TempHumid> THData = new List<TempHumid>();
      
        while (execute.Read())
        {
            THData.Add(new TempHumid()
            { 
                Temperature = execute.GetInt32("temperature"),
                Humidity = execute.GetInt32("humidity"),
                ID = execute.GetString("id"),
                DataInsert = execute.GetDateTime("datetime")
            });
        }

        List<SysUser> UserTH = DBUtl.GetList<SysUser>("SELECT * FROM SysUser where FullName = '" + User.Identity!.Name + "'");

        for (int i = 0; i < THData.Count; i++)
        {
            if (THData[i].Temperature > UserTH[0].ATT || THData[i].Temperature < UserTH[0].BTT)
            {
                TempData["Message"] = "Threshold Exceeded. Current Threshold: " + UserTH[0].ATT + " & " + UserTH[0].BTT;
                TempData["MsgType"] = "danger";
            } else
            {
                TempData["Message"] = "Under Threshold. Current Threshold: " + UserTH[0].ATT + " & " + UserTH[0].BTT;
                TempData["MsgType"] = "success";
            }
        }

        // Pass data to view
        conn.Close();
        return View(THData);

    }

    [Authorize(Roles = "admin, farmer")]
    public IActionResult test3()
    {
        List<DataPoint> test4 = new List<DataPoint>();
        List<DataPoint> test5 = new List<DataPoint>();

        // Create MySQL connection and define Query
        MySqlConnection conn = new MySqlConnection("server=localhost;uid=root;pwd=;database=esp32");
        MySqlCommand query = new MySqlCommand("SELECT * FROM dht22", conn);

        // Open connection and execute query
        conn.Open();
        MySqlDataReader execute = query.ExecuteReader();

        // Read data into list
        List<TempHumid> THData = new List<TempHumid>();

        while (execute.Read())
        {
            THData.Add(new TempHumid()
            {
                Temperature = execute.GetInt32("temperature"),
                Humidity = execute.GetInt32("humidity"),
                ID = execute.GetString("id"),
                DataInsert = execute.GetDateTime("datetime"),
            });
        }
        //string x = "";
        for (int i = THData.Count - 30; i < THData.Count; i ++)
        {
            //x = (1+i).ToString();
            test4.Add(new DataPoint(THData[i].DataInsert.ToString(), THData[i].Temperature));
            test5.Add(new DataPoint(THData[i].DataInsert.ToString(), THData[i].Humidity));
        }

        ViewBag.DataPoints1 = JsonConvert.SerializeObject(test4);
        ViewBag.DataPoints2 = JsonConvert.SerializeObject(test5);

        //-----------------------------------------

        //Second query to get Threshold from Sysuser
        List<SysUser> UserTH = DBUtl.GetList<SysUser>("SELECT * FROM SysUser where FullName = '" + User.Identity!.Name + "'");
        int count = THData.Count;
        if (THData[count - 1].Temperature > UserTH[0].ATT || THData[count - 1].Temperature < UserTH[0].BTT)
        {
            TempData["Message"] = "Threshold Exceeded/Subceed. Temperature Threshold: " + UserTH[0].BTT + "-" + UserTH[0].ATT;
            TempData["MsgType"] = "danger";
        }
        else
        {
            TempData["Message"] = "Within Threshold. Current Threshold: " + UserTH[0].BTT + "-" + UserTH[0].ATT;
            TempData["MsgType"] = "success";
        }
        // Pass data to view
        conn.Close();
        return View();
    }
}